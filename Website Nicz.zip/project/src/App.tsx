import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Countdown from 'react-countdown';
import { 
  Zap, 
  Star, 
  ExternalLink, 
  Github, 
  Menu, 
  X,
  Mail
} from 'lucide-react';

function StarryBackground() {
  useEffect(() => {
    const createStar = () => {
      const star = document.createElement('div');
      star.className = 'star';
      star.style.width = Math.random() * 3 + 'px';
      star.style.height = star.style.width;
      star.style.left = Math.random() * 100 + 'vw';
      star.style.top = Math.random() * 100 + 'vh';
      star.style.animationDelay = Math.random() * 3 + 's';
      return star;
    };

    const starryBg = document.createElement('div');
    starryBg.className = 'starry-bg';
    
    for (let i = 0; i < 100; i++) {
      starryBg.appendChild(createStar());
    }
    
    document.body.appendChild(starryBg);

    return () => {
      document.body.removeChild(starryBg);
    };
  }, []);

  return null;
}

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const techLogos = [
    { name: "Vite", url: "https://vitejs.dev/", logo: "https://vitejs.dev/logo.svg" },
    { name: "React", url: "https://react.dev/", logo: "https://vite.dev/assets/react.Dn3lPOaa.svg" },
    { name: "Angular", url: "https://angular.dev/", logo: "https://angular.io/assets/images/logos/angular/angular.svg" },
    { name: "Vue", url: "https://vuejs.org/", logo: "https://vuejs.org/images/logo.png" },
    { name: "Solid", url: "https://www.solidjs.com/", logo: "https://www.solidjs.com/img/logo/without-wordmark/logo.svg" },
    { name: "Svelte", url: "https://svelte.dev/", logo: "https://svelte.dev/svelte-logo.svg" },
    { name: "Preact", url: "https://preactjs.com/", logo: "https://preactjs.com/assets/app-icon.png" },
    { name: "Astro", url: "https://astro.build/", logo: "https://astro.build/assets/press/astro-icon-light.svg" },
    { name: "Remix", url: "https://remix.run/", logo: "https://remix.run/img/remix-logo.svg" },
    { name: "Nuxt", url: "https://nuxt.com/", logo: "https://nuxt.com/assets/design-kit/logo/icon-green.svg" },
    { name: "Qwik", url: "https://qwik.dev/", logo: "https://qwik.dev/logos/qwik-logo.svg" },
    { name: "RedwoodJS", url: "https://redwoodjs.com/", logo: "https://redwoodjs.com/images/logo.svg" }
  ];

  const platinumSponsors = [
    { name: "Storyblok", url: "https://www.storyblok.com/", logo: "https://www.storyblok.com/images/logo.svg" },
    { name: "Bit", url: "https://bit.dev/", logo: "https://static.bit.dev/bit-logo.svg" }
  ];

  const goldSponsors = [
    { name: "Tailwind CSS", url: "https://tailwindcss.com/", logo: "https://tailwindcss.com/favicons/apple-touch-icon.png" },
    { name: "Prefect", url: "https://www.prefect.io/", logo: "https://www.prefect.io/images/prefect-logo.svg" },
    { name: "Divriots", url: "https://divriots.com/", logo: "https://divriots.com/favicon.png" },
    { name: "JetBrains", url: "https://www.jetbrains.com/", logo: "https://resources.jetbrains.com/storage/products/company/brand/logos/jb_beam.svg" },
    { name: "Mux", url: "https://mux.com/", logo: "https://sponsors.vuejs.org/images/mux.svg" },
    { name: "Remix", url: "https://remix.run/", logo: "https://remix.run/img/remix-logo.svg" },
    { name: "Nx", url: "https://nx.dev/", logo: "https://nx.dev/images/nx-logo.png" }
  ];

  const conferenceDate = new Date('2024-09-01T00:00:00');

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white">
      <StarryBackground />
      
      {/* Announcement Bar */}
      <div className="bg-blue-600 text-white py-2 px-4">
        <div className="max-w-7xl mx-auto text-center text-sm">
          The Build Tool for the Web - Powering the next generation of web applications with speed, efficiency, and scalability.
        </div>
      </div>

      {/* Navigation */}
      <nav className="border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <a 
                href="https://niing.ghost.io" 
                className="flex items-center space-x-2 glow"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img 
                  src="https://niing.ghost.io/content/images/2024/03/niing-logo.png" 
                  alt="Niing Logo" 
                  className="h-8 w-8"
                />
                <span className="text-xl font-bold">Nicz</span>
              </a>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              <a href="#about" className="text-gray-300 hover:text-white transition-colors glow">About</a>
              <a 
                href="https://github.com/" 
                className="flex items-center gap-2 text-gray-300 hover:text-white transition-colors glow"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Github size={20} />
                GitHub
              </a>
            </div>

            {/* Mobile Navigation */}
            <div className="md:hidden">
              <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-gray-300">
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <a href="#about" className="block px-3 py-2 text-gray-300 hover:text-white transition-colors glow">About</a>
              <a 
                href="https://github.com/" 
                className="flex items-center gap-2 px-3 py-2 text-gray-300 hover:text-white transition-colors glow"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Github size={20} />
                GitHub
              </a>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section with Animated Brand Slider */}
      <div className="relative py-24 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-blue-900/20 to-transparent" />
        
        {/* Brand Slider */}
        <div className="relative overflow-hidden py-12 before:absolute before:left-0 before:top-0 before:z-10 before:h-full before:w-24 before:bg-gradient-to-r before:from-[#0A0A0A] before:to-transparent after:absolute after:right-0 after:top-0 after:z-10 after:h-full after:w-24 after:bg-gradient-to-l after:from-[#0A0A0A] after:to-transparent">
          {/* First Row */}
          <motion.div
            className="flex space-x-8 mb-8"
            animate={{ x: [0, -1920] }}
            transition={{ 
              repeat: Infinity,
              duration: 50,
              ease: "linear"
            }}
          >
            {[...techLogos, ...techLogos].map((logo, index) => (
              <div
                key={`${logo.name}-${index}`}
                className="flex-shrink-0 w-24 h-24 bg-white/5 rounded-lg p-4 flex items-center justify-center"
              >
                <img src={logo.logo} alt={logo.name} className="w-16 h-16 object-contain" />
              </div>
            ))}
          </motion.div>

          {/* Second Row */}
          <motion.div
            className="flex space-x-8"
            animate={{ x: [-1920, 0] }}
            transition={{ 
              repeat: Infinity,
              duration: 50,
              ease: "linear"
            }}
          >
            {[...techLogos, ...techLogos].map((logo, index) => (
              <div
                key={`${logo.name}-${index}-reverse`}
                className="flex-shrink-0 w-24 h-24 bg-white/5 rounded-lg p-4 flex items-center justify-center"
              >
                <img src={logo.logo} alt={logo.name} className="w-16 h-16 object-contain" />
              </div>
            ))}
          </motion.div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            First Ever in-person Nicz Conference
          </h1>
          <p className="text-xl md:text-2xl text-gray-400 mb-12">
            Join us for the next generation tooling for most frameworks when building an SPA and powers almost every JavaScript meta-framework!
          </p>
          
          {/* Countdown Timer */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold mb-4">Tickets Released In</h2>
            <Countdown 
              date={conferenceDate}
              renderer={({ days, hours, minutes, seconds }) => (
                <div className="flex justify-center gap-8">
                  <div className="text-center">
                    <div className="text-4xl font-bold">{days}</div>
                    <div className="text-gray-400">days</div>
                  </div>
                  <div className="text-center">
                    <div className="text-4xl font-bold">{hours}</div>
                    <div className="text-gray-400">hours</div>
                  </div>
                  <div className="text-center">
                    <div className="text-4xl font-bold">{minutes}</div>
                    <div className="text-gray-400">minutes</div>
                  </div>
                  <div className="text-center">
                    <div className="text-4xl font-bold">{seconds}</div>
                    <div className="text-gray-400">seconds</div>
                  </div>
                </div>
              )}
            />
          </div>
        </div>
      </div>

      {/* About Section */}
      <div id="about" className="py-24 bg-black/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold mb-8">About Nicz</h2>
            <div className="prose prose-invert">
              <p className="text-gray-300 mb-6">
                At Nicz, we believe in pushing the boundaries of web development. Our mission is to create innovative, fast, and scalable websites that empower developers and businesses. We partner with the best tools in the industry, such as Vite, Bolt, and more, to ensure high-performance and seamless development experiences.
              </p>
              <p className="text-gray-300 mb-6">
                With a deep passion for technology, we strive to make web development accessible to everyone, from hobbyists to professionals. Whether you're building a new project or optimizing an existing one, we provide the resources, tools, and knowledge to help you succeed.
              </p>
            </div>

            <h2 className="text-3xl font-bold mt-16 mb-8">Unfuck Our Future</h2>
            <div className="prose prose-invert">
              <p className="text-gray-300 mb-6">
                This is the part where we tell you how amazing we are. And we'll get to that. But first, we want to talk about our future. The world is facing an unprecedented crisis as climate change impacts all life on Earth. To put it bluntly, without drastic action, our future is fucked.
              </p>
              <p className="text-gray-300">
                But... all over the world people are engineering new technologies, ideas and behaviours to help address this crisis. And we want to help them succeed. We'll do that by helping to accelerate adoption of these breakthrough solutions. Together we can Unfuck Our Future.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Frameworks Section */}
      <div className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-4">Powering your favorite frameworks and tools</h2>
          <p className="text-center text-gray-400 mb-12">A shared foundation to build upon</p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8">
            {techLogos.map((framework) => (
              <a
                key={framework.name}
                href={framework.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex flex-col items-center justify-center p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-all group"
              >
                <img
                  src={framework.logo}
                  alt={`${framework.name} logo`}
                  className="h-12 w-12 object-contain mb-2 group-hover:scale-110 transition-transform"
                />
                <span className="text-sm text-gray-400 group-hover:text-white flex items-center gap-1">
                  {framework.name}
                  <ExternalLink size={12} />
                </span>
              </a>
            ))}
          </div>
        </div>
      </div>

      {/* Sponsors Section */}
      <div className="py-24 bg-black/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-16">Free & open source</h2>
          
          <div className="mb-24">
            <h3 className="text-2xl font-bold text-center mb-8">Platinum Sponsors</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-2xl mx-auto">
              {platinumSponsors.map((sponsor) => (
                <a
                  key={sponsor.name}
                  href={sponsor.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center p-8 rounded-lg bg-white/5 hover:bg-white/10 transition-all group"
                >
                  <img
                    src={sponsor.logo}
                    alt={`${sponsor.name} logo`}
                    className="h-16 object-contain group-hover:scale-105 transition-transform"
                  />
                </a>
              ))}
            </div>
          </div>

          <div className="mb-24">
            <h3 className="text-2xl font-bold text-center mb-8">Gold Sponsors</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {goldSponsors.map((sponsor) => (
                <a
                  key={sponsor.name}
                  href={sponsor.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center p-6 rounded-lg bg-white/5 hover:bg-white/10 transition-all group"
                >
                  <img
                    src={sponsor.logo}
                    alt={`${sponsor.name} logo`}
                    className="h-12 object-contain group-hover:scale-105 transition-transform"
                  />
                </a>
              ))}
            </div>
          </div>

          <div className="text-center">
            <h3 className="text-2xl font-bold mb-4">Become a Sponsor</h3>
            <a
              href="mailto:nicztin@gmail.com"
              className="inline-flex items-center gap-2 text-blue-400 hover:text-blue-300 transition-colors"
            >
              <Mail size={20} />
              nicztin@gmail.com
            </a>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Start innovate with Nicztin</h2>
          <p className="text-xl text-gray-400 mb-12">
            Prepare for a development environment that can finally keep pace with the speed of your mind.
          </p>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-white/10 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-gray-400">
            <p className="mb-4">Released under the MIT License.</p>
            <p>Copyright © Netilfy & Nicztin Contributors</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;